package com.example.meetingapp.model

data class Account(var name : String?, val email : String, val password : String) {

}